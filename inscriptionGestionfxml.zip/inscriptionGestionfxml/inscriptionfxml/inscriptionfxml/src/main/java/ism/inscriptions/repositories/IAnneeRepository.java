package ism.inscriptions.repositories;

import java.util.List;

public interface IAnneeRepository {
    public List<String> findAll();
}
