package ism.inscriptions.core;

public interface IDatabase {
    public void ouvrirConnexionBd();
    public void fermerConnexionBd();  
}
